%% Butterfly SWARM OPTIMIZATION %%
clc
clear all
close all
%% Initialization
[X,Y] = meshgrid(-3:.1:3,-3:.1:3);
Z = fitness(X,Y);

% Parameters
iter_max = 150;
NoofAgents = 50;
dimension = 2;
k = 1;
step = 0.05;
iter=1;
UV = ones(NoofAgents,1)*10;
c1 = 0;   % Gbest Velocity Updation Constant
c2 = 1;   % local best Velocity Updation Constant
c3 = 3;
c4 = .01;   % UV(iter) = c4 * UV(iter) + c3 * fitness
 
swarm=zeros(NoofAgents,2*dimension+2,iter_max);

tic
% Randomly deploying agents
for i=1:NoofAgents
    for j =1:dimension
        swarm(i,j,iter) = 3*(rand-0.5)/0.5;
    end        
end
% 
% s_x = swarm(:,1,1);
% s_y = swarm(:,2,1);
% save('s_x','s_x')
% save('s_y','s_y')

% load('s_x')
% load('s_y')
% swarm(:,1,1) = s_x;
% swarm(:,2,1) = s_y;
% 
swarm(:,7,iter) = fitness(swarm(:,1,iter),swarm(:,2,iter));
UV = c4*UV + c3*swarm(:,7,iter);
swarm(:,8,iter) = UV;
disp('Running Code....')
for iter=2:iter_max
    fprintf('%dth Iteration running\n',iter)
    
    % Update Position
    for i = 1:dimension
        swarm(:,i,iter) = swarm(:,i,iter-1)+swarm(:,i+dimension,iter-1);        
    end
    
    
    % Update UV
    swarm(:,7,iter) = fitness(swarm(:,1,iter),swarm(:,2,iter));
    UV = c4*UV + c3*swarm(:,7,iter);
    swarm(:,8,iter) = UV;
    
    % find Gbest
    for i=1:NoofAgents
        for j=i+1:NoofAgents
            DDist(i,j) = 1/sqrt(sum((swarm(i,1:dimension,iter)-swarm(j,1:dimension,iter)).^2));
            DDist(j,i) = DDist(i,j);
        end
    end
    
    UUv(:,:,iter) = repmat(UV,[1 NoofAgents]).*DDist./repmat(sum(DDist')',[1 NoofAgents]);    
    
%     UUv = repmat(UV,[1 NoofAgents]);  

    for i=1:NoofAgents
        [temp1 temp2]= sort(UUv(:,i,iter),'descend');
        loc_best(i) = i;
        MMin = UV(i);
        for j=1:NoofAgents
            if (UV(i)<UV(temp2(j)))
                if MMin<UV(temp2(j))
                    loc_best(i) = temp2(j);
                    MMin = UV(temp2(j));
                    break
                end
            end
        end
    end    
    
    gbest(NoofAgents,1) = 0;
    
    swarm(:,5,iter)=gbest;
    swarm(:,6,iter)=loc_best;
    
    % Update Velocity
    for i = 1 : NoofAgents
        for j = 1 : dimension
            swarm(i, j+dimension,iter) = c2*(swarm(loc_best(i),j,iter) - swarm(i, j,iter));                      
        end 
        temp(i,1) = sqrt(sum(swarm(i,dimension+1:dimension*2,iter).^2)); % norm of position vectors    
        if(temp(i,1)==0)
            temp(i,1)=1;
        end
    end   
    
    for j = 1:dimension
        swarm(:,j+dimension,iter) = (swarm(:,j+dimension,iter)./temp)*step;
    end    
    
end

time = toc;
fprintf('Time: %f \n',time)
[temp1 temp2]=max(swarm(:,7,iter));
[swarm(temp2,1,iter) swarm(temp2,2,iter) temp1]
disp('Plotting....')
%% Plotting the behaviour of each agent for each iteration

% Iteration wise behavior of Bflies
figure(1)
for i=1:iter_max
    clf
    contour(X,Y,Z,10)
    hold on
    plot(swarm(:,1,i),swarm(:,2,i),'r*');
    ttl = strcat('Iteration: ',num2str(i));
    title(ttl)
    axis([-3 3 -3 3]);
    grid on
    pause(0.08)
end

% Ploting the emergence path for each agent
figure(3)
contour(X,Y,Z,20);
hold on
for j=1:NoofAgents
    for i=1:iter_max
        x(i)=swarm(j,1,i);
        y(i)=swarm(j,2,i);
    end
    plot(x,y,'b', x(1), y(1),'r*',0,1.58,'kO')
    axis([-pi pi -pi pi])
    grid on
    hold on
end
title('Convergence Profile')

% % UV convergence plot
% figure(3)
% for i=1:NoofAgents
%     tt = swarm(i,8,:);
%     tt = tt(:);
%     plot(tt,'-b');
%     hold on
% end
% xlabel('iteration')
% ylabel('UV of Bfly')
% grid on
% title('UV Convergence');
% 
% figure(4)
% clear x;clear y;
% contour(X,Y,Z,10);
% hold on
% for j=1:NoofAgents
%     for i=1:iter_max
%         x(i)=swarm(j,1,i);
%         y(i)=swarm(j,2,i);
% %         x(i-9)=swarm(j,1,i);
% %         y(i-9)=swarm(j,2,i);
%     end
%     plot(x,y,'b', x(1), y(1),'r*',0,1.58,'kO')
%     axis([-pi pi -pi pi])
%     grid on
%     hold on
% end
% title('Test Cases')
% 
